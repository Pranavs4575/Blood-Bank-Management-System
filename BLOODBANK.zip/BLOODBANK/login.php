<?php

session_start();
$_SESSION['user_login']=false;
$_SESSION['admin_login']=false;

$unumber=$_POST['number'];
$upassword=$_POST['password'];

if($unumber=='8483934575' && $upassword=='Admin@12_21'){
    header("location: admin/bank.php");
    $_SESSION['admin_login']=true;
}
else{

    include "connection.php";

    $sql_result= mysqli_query($conn,"select * from user where number='$unumber' and password='$upassword'");

    $tabel=mysqli_fetch_assoc($sql_result);
    $rows= mysqli_num_rows($sql_result);

    if($rows>0){
        $_SESSION['user_login']=true;
        $_SESSION['user_number']=$tabel['number'];
    // $_SESSION['user_password']=$tabel['password'];
        header("location: user/home.php");
    }else{
        header("location: login.html");
    }
}

?>