<?php
if (isset($_GET['userId']) && isset($_GET['username']) && isset($_GET['userType'])) {
    $userId = $_GET['userId'];
    $username = $_GET['username'];
    $userType = $_GET['userType'];

    // Generate certificate HTML content
    $certificateContent = '<!DOCTYPE html>
    <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You Blood Donor Certificate</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .certificate {
            max-width: 1200px;
            margin: 50px auto;
            background-image: url(public/img1.jpg);
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover; /* Spread image over the entire container */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }

        .certificate h1 {
            color: red;
            font-size: 28px;
            margin-bottom: 20px;
            margin-left: 140px;
        }
        .certificate h2{
            margin-left: 140px;
        }

        .certificate p {
            color: #000000;
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 10px;
            margin-left: 140px;
        }

        .signature {
            margin-top: 40px;
            
        }

        .signature p {
            margin-bottom: 5px;
            color: #555;
            font-size: 16px;
        }

        .signature img {
            margin-left: 600px;
            display: block;
            width: 150px;
            height: auto;
            border-radius: 50%;
        }
    </style>
    <script>
        // JavaScript function to print the certificate when clicking anywhere within the certificate frame
        function printCertificate() {
            window.print();
        }
    </script>
</head>
<body>
    <div class="certificate" onclick="printCertificate()">
        <h1>Thank You Certificate</h1>
        <p>This is to certify that</p>
        <h2>' . (isset($_GET['username']) ? $_GET['username'] : 'Unknown Donor') . '</h2>
        <p>has made a significant contribution to our community by donating blood on</p>
        <p>' . (isset($_GET['donation_date']) ? $_GET['donation_date'] : 'Unknown Date') . '</p>
        <p>Your selfless act has helped save lives and made a positive impact on our community.</p>
        <div class="signature">
            <p>With gratitude,</p>
            <img src="public/signature.png" alt="Director Signature">
            <p>Director, Blood Bank</p>
        </div>
    </div>
</body>
</html>';

    // Output the certificate content
    echo $certificateContent;
} else {
    echo "Invalid request. Please provide user details.";
}
?>
