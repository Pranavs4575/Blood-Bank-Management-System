<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate List</title>
    <style>
        div.user {
            display: inline-block;
            border: 1px solid black;
            padding: 10px;
            margin: 10px;
        }
    </style>
</head>
<body>
<?php
include("connection.php");

$sql = "SELECT * FROM users ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='user'>";
        echo "User ID: " . $row["userid"] . "<br>";
        echo "Username: " . $row["username"] . "<br>";
        echo "User Type: " . $row["usertype"] . "<br>";
        echo "<button onclick='getCertificate(\"" . $row["userid"] . "\", \"" . $row["username"] . "\", \"" . $row["usertype"] . "\")'>Get Certificate</button>";
        echo "</div>";
    }
} else {
    echo "No user found";
}

mysqli_close($conn);
?>

<script>
    function getCertificate(userId, username, userType) {
        window.location.href = "generate.php?userId=" + userId + "&username=" + encodeURIComponent(username) + "&userType=" + encodeURIComponent(userType);
    }
</script>
</body>
</html>
