<?php
    include "../../connection.php";

    $uid=$_GET['uid'];
    $status = mysqli_query($conn,"update donation set status='Rejected' where uid= '$uid'");
    header("location: ../donationlist.php");
    
?>