<?php
    include "../../connection.php";

    $uid=$_GET['uid'];
    $status = mysqli_query($conn,"update request set status='Rejected' where uid= '$uid'");
    header("location: ../requestlist.php");
    
?>