<?php

    $uid=$_POST['id'];
    $ubloodgrp=$_POST['bloodgrp'];
    $udate=date('Y-m-d', strtotime($_POST['date']));
    $uunit=$_POST['unit'];
    $uorgn=$_POST['organization'];


    include "../connection.php";
    $status = mysqli_query($conn,"update donation set bloodgroup='$ubloodgrp', date='$udate', unit='$uunit', organization='$uorgn', status='Completed' where uid= '$uid'");

    header("location: bank.php");

?>