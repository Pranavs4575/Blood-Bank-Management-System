<?php
    include"authguard.php";
    include "menu.html";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Donation Form</title>
    <style>
    *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
        }

    body{
    background-size: cover;
    background-repeat: no-repeat;
    display: flex;
    justify-content: center;
    height: 100vh;
    background-position: center;
    background-attachment: fixed;
    overflow: hidden;
    background-color: skyblue;
    font-family: Arial, sans-serif;
    }

        .outer {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin-top: 4px;
            width: 400px;
        }

        .inner {
            width: 90%;
            max-width: 600px; /* Set maximum width */
            background: rgba(255, 255, 255, 0.247);
            backdrop-filter: blur(5px);
            border: #b8b7b7;
            transition: transform .5s ease,height .2s ease;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: rgb(62, 61, 61);
        }

        .Registration_form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
        }

        input,
        select {
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            font-size: 16px;
            background-color: transparent;
            border-bottom: 1px solid rgba(0, 0, 0, 0.866);
            outline: none; 
        }

        input::placeholder,
        select::placeholder {
            color: rgba(0, 0, 0, 0.866);
        }

        .Submit_btn {
            padding: 10px 0;
            background-color: rgb(108, 108, 239);
            color: white;
            border: none;
            margin-top: 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .Submit_btn:hover {
            opacity: 0.5;
        }

        /* Media query for smaller screens */
        @media screen and (max-width: 500px) {
            .inner {
                padding: 20px; /* Adjust padding for smaller screens */
            }
        }
        .navigation .set4{
            color: gray;
        }
    </style>
</head>
<body>
    <div class="outer">
        <div class="inner">
            <h1>Donate Form</h1>
            <form action="donateform.php" method="post" class="Registration_form">
                <input type="number" id="mobile" name="id" placeholder="Donation id" required>
                <select id="bloodgrp" class="bloodgrp" name="bloodgrp" required>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
                <input type="date" id="date" name="date" placeholder="Enter Date"required>
                <input type="number" id="blood_unit" name="unit" placeholder="Blood_unit" required min="1">
                <input type="text" id="organization" name="organization" placeholder=" Enter Organization Name" required>

                <button type="submit" class="Submit_btn">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>
