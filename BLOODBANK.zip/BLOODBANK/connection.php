<?php
try {
    $conn = new mysqli("localhost", "root", "", "bloodbank");
    if ($conn->connect_error) {
        echo "Connection Failed";
        die;
    }
} catch (Exception $err) {
    echo"You have found a error";
    print_r($err);
}
?>
