<?php

    $unumber=$_POST['number'];
    $uname=$_POST['name'];
    $uemail=$_POST['email'];
    $uage=$_POST['age'];
    $upassword=$_POST['password'];


    $conn = new mysqli("localhost","root","","bloodbank");
    $status = mysqli_query($conn,"insert into user (number,name,email,age,password) values('$unumber','$uname','$uemail','$uage','$upassword')");
    if($status){
        // header("location: buyer/view.php");
        header("location: login.html");
    }
    else{
        echo "Error";
        echo mysqli_error($conn);
    }

    mysqli_close($conn);
?>