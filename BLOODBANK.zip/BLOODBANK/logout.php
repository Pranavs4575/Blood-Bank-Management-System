<?php
session_start();
$_SESSION['user_login'] = false;
$_SESSION['admin_login'] = false;
header("location: login.html");
exit();
?>
