<?php
include "connection.php";
$bloodgroupSums = array();
$bloodgroups = array('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-');

foreach ($bloodgroups as $bloodgroup) {
    $query = "SELECT SUM(unit) AS total_donation FROM donation WHERE bloodgroup = '$bloodgroup' and status= 'Completed' ";
    $query2 = "SELECT SUM(unit) AS total_request FROM request WHERE bloodgroup = '$bloodgroup' and status= 'Completed' ";
    $result = mysqli_query($conn, $query);
    $result2 = mysqli_query($conn, $query2);
    if ($result || $result2) {
        $row = mysqli_fetch_assoc($result);
        $row2= mysqli_fetch_assoc($result2);
        $bloodgroupSums[$bloodgroup] = $row['total_donation']-$row2['total_request'];
        mysqli_free_result($result);
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
