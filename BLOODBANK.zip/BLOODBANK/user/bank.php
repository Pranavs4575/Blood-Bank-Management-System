<?php
    include"authguard.php";
    include"../bloodcount.php";
    include "menu.html";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: 'Josefin Sans', sans-serif;
            background-color: skyblue;
            margin: 0;
            padding: 0;
            
        }

        .wrapper1 {
            width: 90%;
            height: 100vh;
            overflow-x: auto; /* Enable horizontal scrolling for smaller screens */
        }

        .main_content {
            width: 100%;
            align-items: center;
        }

        .container1 {
            margin-top: 100px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); /* Adjust card width */
            gap: 30px;
            padding: 20px;
            justify-content: center; 
        }

        .card1 {
            margin: 10px;
            width: 250px;
            background-color: rgba(255, 255, 255, 0.529);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center; /* Center-align the content inside the card */
        }

        .card1 h2 {
            font-size: 24px;
            color: #2e2e2e;
            margin-bottom: 10px; /* Add margin bottom to separate the title and count */
        }

        .card1 .blood i {
            color: red;
        }

        .card1 .unit {
            font-size: 18px;
        }
        .navigation .set2{
            color: gray;
        }

    </style>
</head>
<body>
<div class="wrapper1">
    <div class="main_content">
        <div class="container1">
            <div class="card1">
                <div class="blood">
                    <h2>A+ <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span ><?php echo $bloodgroupSums['A+'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>B+ <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span ><?php echo $bloodgroupSums['B+'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>O+ <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $bloodgroupSums['O+'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>AB+ <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $bloodgroupSums['AB+'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>A- <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $bloodgroupSums['A-'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>B- <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $bloodgroupSums['B-'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>O- <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $bloodgroupSums['O-'] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>AB- <i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $bloodgroupSums['AB-'] ?></span></div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
