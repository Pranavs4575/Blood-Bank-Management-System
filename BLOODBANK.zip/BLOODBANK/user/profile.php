<?php
    include"authguard.php";
    include"../connection.php";
    include"records.php";
    include "menu.html";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: 'Josefin Sans', sans-serif;
            background-color: skyblue;
            margin: 0;
            padding: 0;
            display: block;
            overflow-y: scroll;
            justify-content: center;
            overflow-x: hidden;
            
        }

        .wrapper1 {
            width: 90%;
            height: fit-content;
            overflow-x: auto; /* Enable horizontal scrolling for smaller screens */
            margin-left: auto;
        }

        .main_content {
            width: 100%;
            align-items: center;
        }

        .container1 {
            margin-top: 100px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); /* Adjust card width */
            gap: 30px;
            padding: 20px;
            justify-content: center; 
        }

        .card1 {
            margin: 10px;
            width: 250px;
            background-color: rgba(255, 255, 255, 0.529);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center; /* Center-align the content inside the card */
        }

        .card1 h2 {
            font-size: 24px;
            color: #2e2e2e;
            margin-bottom: 10px; /* Add margin bottom to separate the title and count */
        }

        .card1 .blood i {
            color: red;
        }

        .card1 .unit {
            font-size: 18px;
        }
        .navigation .set6{
            color: gray;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            margin-top: 50px;
        }
        /* Card styles */
        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        /* Card header styles */
        .card-header {
            background-color: rgba(255, 255, 255, 0.529);
            color: black;
            padding: 10px 20px;
            border-radius: 5px 5px 0 0;
        }
        /* Table styles */
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        /* Table header styles */
        .table th {
            padding: 12px;
            text-align: left;
            background-color:rgba(255, 255, 255, 0.529);
            color: black;
        }
        /* Alternate row styles */
        .table tbody tr{
            background-color: #f2f2f2;
        }
        /* Table cell styles */
        .table td {
            padding: 10px;
        }
        /* Logout button styles */
        .logout-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .logout-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgba(255, 255, 255, 0.529);
            color: black;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            margin-bottom: 30px;
        }
        .logout-button:hover {
            background-color: #0056b3;
        }

    </style>
</head>
<body>
<div class="wrapper1">
    <div class="main_content">
        <div class="container1">
            <div class="card1">
                <div class="blood">
                    <h2>Donation Accepted<i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $count["Daccept"] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>Donation Rejected<i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $count["Dreject"] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>Request Accepted<i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $count["Raccept"] ?></span></div>
            </div>
            <div class="card1">
                <div class="blood">
                    <h2>Request Rejected<i class="fas fa-tint"></i></h2>
                </div>
                <div class="unit">Count: <span><?php echo $count["Rreject"] ?></span></div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>Donation History</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Number</th>
                            <th>Name</th>
                            <th>BloodGroup</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT * FROM donation WHERE number='{$_SESSION['user_number']}'";
                            $query_run = mysqli_query($conn, $query);
                            foreach($query_run as $list){
                                    ?>
                                    <tr>
                                        <td><?= $list['uid']; ?></td>
                                        <td><?= $list['number']; ?></td>
                                        <td><?= $list['name']; ?></td>
                                        <td><?= $list['bloodgroup']; ?></td>
                                        <td><?= $list['status']; ?></td>
                                    </tr>
                                    <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h2>Request History</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Number</th>
                            <th>Name</th>
                            <th>BloodGroup</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT * FROM request WHERE number='{$_SESSION['user_number']}'";
                            $query_run = mysqli_query($conn, $query);
                            foreach($query_run as $list){
                                    ?>
                                    <tr>
                                        <td><?= $list['uid']; ?></td>
                                        <td><?= $list['number']; ?></td>
                                        <td><?= $list['name']; ?></td>
                                        <td><?= $list['bloodgroup']; ?></td>
                                        <td><?= $list['status']; ?></td>
                                    </tr>
                                    <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="logout-container">
    <a href="../logout.php" class="logout-button">Logout</a>
</div>

</body>
</html>
