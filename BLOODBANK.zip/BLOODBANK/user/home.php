<?php
    include"authguard.php";
    include "menu.html";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Home</title>
    <style>
        /* Reset default browser styles */
* {
    color: #000;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Set blue background */
body {
    
    text-align: center;
    color: #000; /* White text */
    font-family: Arial, sans-serif;
}

p{
    color: white;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    margin-top: 150px;
}

h5{
    color: White;
    font-family: 'Times New Roman', Times, serif;
    font-style: italic;
}



button {
    background-color: #e5e7e9; /* White background */
    color: #1faad8; /* Blue text */
    border: none;
    padding: 10px 20px;
    border-radius: 20px;
    font-size: 16px;
    cursor: pointer;
    margin-top: 20px;
    font-weight: bold;
}

button:hover {
    background-color: #f84242; /* Darker blue on hover */
}

.contact-details {
    margin-top: 20px;
}



.contact-details ul {
    list-style-type: none;
}

.contact-details ul li {
    margin-bottom: 10px;
}

.contact-details ul li:before {
    content: "\2022"; /* Bullet symbol */
    color: #fff; /* White bullet */
    display: inline-block;
    width: 1em;
    margin-left: -1em;
}

.contact-details ul li:first-child:before {
    content: none; /* Remove bullet for first item */
}

.navigation .set1{
    color: gray;
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Our Blood Bank</h1><br>
        <p>Donate Blood, Save Lives!</p>
        <p>Together, we can make a difference.</p>
        <button onclick="window.location.href='donate.php'">Donate Now</button>

        <div class="contact-details">
            <h2>Contact Details</h2>
            <p>For inquiries, please contact:</p><br>
                <h5>Manager:Dr. Pranav Salunkhe</h5>
                <h5>Phone: +91 84839 34575</h5>
                <h5>Address: Bharat Mata Society Ichalkaranji</h5>
            </ul>
        </div>
    </div>
</body>
</html>