<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate List</title>
    <style>
    *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
        }

    body{
    background-size: cover;
    background-repeat: no-repeat;
    display: flex;
    justify-content: center;
    height: 100vh;
    background-position: center;
    background-attachment: fixed;
    overflow: hidden;
    background-color: skyblue;
    font-family: Arial, sans-serif;
    }
        b{
            margin-top: 120px;
        }

        .user {
            display: inline-block;
            border: 1px solid rgba(0, 0, 0, 0.2);
            padding: 5px;
            margin: 10px;
            width: 200px; /* Set the width to 200px */
            height: 150px; /* Set the height to 50px */
            max-width: 90%; /* Limit the maximum width */
            background-color: rgba(190, 226, 233, 0.796); /* Blurry white background */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Box shadow for a subtle blur effect */
        }

        .user button {
            background-color: #007bff; /* Blue button background */
            color: white; /* White text color */
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .user button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        .navigation .set5 {
            color: gray;
        }
    </style>
</head>
<body>
    <b>
<?php
    include "authguard.php";
    include "../connection.php";
    include "menu.html";

    $sql = "SELECT * FROM donation where status='Completed' and number={$_SESSION['user_number']}";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='user'>";
            echo "User ID: " . $row["uid"] . "<br>";
            echo "Username: " . $row["name"] . "<br>";
            echo "User Type: " . $row["date"] . "<br><br>";
            echo "<button onclick='getCertificate(\"" . $row["uid"] . "\",\"" . $row["name"] . "\", \"" . $row["date"] . "\")'>Get Certificate</button>";
            echo "</div>";
        }
    } else {
        echo "No Certificate Yet";
    }

    mysqli_close($conn);
?>
</b>

<script>
    function getCertificate(uid, name, date) {
        window.location.href = "generate.php?uid=" + uid + "&name=" + encodeURIComponent(name) + "&date=" + encodeURIComponent(date);
    }
</script>
</body>
</html>
