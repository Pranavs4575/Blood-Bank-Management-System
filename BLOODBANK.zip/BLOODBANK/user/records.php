<?php
include "../connection.php";
$count = array();

$query = "SELECT count(uid) AS count FROM donation WHERE status = 'Accepted' and number={$_SESSION['user_number']}";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$count["Daccept"] = $row['count'];

$query = "SELECT count(uid) AS count FROM donation WHERE status = 'Rejected' and number={$_SESSION['user_number']}";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$count["Dreject"] = $row['count'];

$query = "SELECT count(uid) AS count FROM request WHERE status = 'Accepted' and number={$_SESSION['user_number']}";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$count["Raccept"] = $row['count'];

$query = "SELECT count(uid) AS count FROM request WHERE status = 'Rejected' and number={$_SESSION['user_number']}";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$count["Rreject"] = $row['count'];

print_r($count);
?>
