<?php

    $unumber=$_POST['number'];
    $uname=$_POST['name'];
    $ubloodgrp=$_POST['bloodgrp'];
    $udisease=$_POST['disease'];


    include "../connection.php";

    $status = mysqli_query($conn,"insert into donation (number,name,bloodgroup,disease) values('$unumber','$uname','$ubloodgrp','$udisease')");
    header("location: profile.php");

?>