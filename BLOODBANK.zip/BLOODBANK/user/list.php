<?php
    // include "authguard.php";
    include "../connection.php";
    include "menu.html";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* Custom CSS */
        /* Container styles */
        body{
            overflow-y: scroll;
        }
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            margin-top: 200px;
        }
        /* Card styles */
        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        /* Card header styles */
        .card-header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px 5px 0 0;
        }
        /* Table styles */
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        /* Table header styles */
        .table th {
            padding: 12px;
            text-align: left;
            background-color: #007bff;
            color: white;
        }
        /* Alternate row styles */
        .table tbody tr{
            background-color: #f2f2f2;
        }
        /* Table cell styles */
        .table td {
            padding: 10px;
        }
        .navigation .set2{
            color: gray;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Donation Approvals</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>BloodGroup</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $query = "SELECT * FROM donation";
                                $query_run = mysqli_query($conn, $query);
                                foreach($query_run as $list){
                                        ?>
                                        <tr>
                                            <td><?= $list['uid']; ?></td>
                                            <td><?= $list['name']; ?></td>
                                            <td><?= $list['bloodgroup']; ?></td>
                                            <td><?= $list['status']; ?></td>
                                        </tr>
                                        <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
