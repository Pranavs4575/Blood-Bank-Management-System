<?php

    $unumber=$_POST['number'];
    $uname=$_POST['name'];
    $ubloodgrp=$_POST['bloodgrp'];
    $ureason=$_POST['reason'];


    include "../connection.php";

    $status = mysqli_query($conn,"insert into request (number,name,bloodgroup,reason) values('$unumber','$uname','$ubloodgrp','$ureason')");
    header("location: profile.php");

?>